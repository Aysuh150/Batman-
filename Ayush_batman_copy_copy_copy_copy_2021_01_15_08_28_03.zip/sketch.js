var batman,batmanimage,bgimage,bulletimage,enemyimage, bulletG,enemyG

function preload(){
  
  batmanimage=loadImage('batman.png')
  bgimage=loadImage('building1.jpg')
  bulletimage=loadImage('Bullet_1.png')
  
}



function setup() {
  createCanvas(500, 400);
  bg =createSprite(250,200,500,400)
  bg.addImage(bgimage)
  bg.scale=0.4
  batman=createSprite(30,350,10,10);
  batman.addImage(batmanimage)
  batman.scale=0.3
  //bg.addImage
  bulletG= new Group();
  enemyG=new Group();
}

function draw() {
  background(220);
  if(keyDown(LEFT_ARROW)){
    batman.x=batman.x+5
  }
  
    if(keyDown(RIGHT_ARROW)){
    batman.x=batman.x-5
  }
    if(keyDown(UP_ARROW)){
    batman.y=batman.y-5
  }
  
    if(keyDown(DOWN_ARROW)){
    batman.y=batman.y+5
  }
  drawSprites()
  if(keyDown("space")){
    bullets()
  }
  enemys()
  
  if(bulletG.isTouching(enemyG)){
    enemyG.destroyEach();
    bulletG.destroyEach();
  }
}

function bullets(){
  bullet=createSprite(100,100,20,20)
  bullet.addImage(bulletimage)
  bullet.scale=0.1
  bullet.velocityX=3
  bullet.x=batman.x
  bullet.y=batman.y
bulletG.add(bullet)
}

function enemys(){
  if (frameCount%100===0){
    enemy=createSprite(600,200,50,50)
    enemy.velocityX=-3
    enemy.shapeColor="red"
    enemy.y=random(100,400)
    enemyG.add(enemy)
  }
    
}
